/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author Familia MV
 */
public class DTO_Tipo_Pago {
    
    
    private Integer Id_Tipo_Pago;
    private Integer Id_Entidad;
    private Integer Id_Nombre_Tp;

    public Integer getId_Tipo_Pago() {
        return Id_Tipo_Pago;
    }

    public void setId_Tipo_Pago(Integer Id_Tipo_Pago) {
        this.Id_Tipo_Pago = Id_Tipo_Pago;
    }

    public Integer getId_Entidad() {
        return Id_Entidad;
    }

    public void setId_Entidad(Integer Id_Entidad) {
        this.Id_Entidad = Id_Entidad;
    }

    public Integer getId_Nombre_Tp() {
        return Id_Nombre_Tp;
    }

    public void setId_Nombre_Tp(Integer Id_Nombre_Tp) {
        this.Id_Nombre_Tp = Id_Nombre_Tp;
    }
    
    
}
